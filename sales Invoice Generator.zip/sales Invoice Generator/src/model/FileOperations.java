package model;

import java.util.ArrayList;

public class FileOperations {
    public void readFile(ArrayList InvoiceLines){

    }
    public void writeFile(ArrayList InvoiceLines){

    }
}
