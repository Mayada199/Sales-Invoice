package model;

import java.util.ArrayList;

public class InvoiceHeader {
  private  int invoiceNum ;
    private String invoiceDate,invoiceDate1;
    private String customerName ;
    ArrayList<InvoiceLine> InvoiceLines = new ArrayList<InvoiceLine>();


    public InvoiceHeader() {
    }

    public ArrayList<InvoiceLine> getInvoiceLines() {
        for (InvoiceLine invoiceLine11 : InvoiceLines) {
           invoiceLine11.toString();
        }
        return InvoiceLines;
    }

    public void setInvoiceLines(ArrayList<InvoiceLine> invoiceLines) {
        InvoiceLines = invoiceLines;
    }

    public InvoiceHeader(int invoiceNum, String invoiceDate, String customerName, ArrayList<InvoiceLine> invoiceLines) {
        this.invoiceNum = invoiceNum;
        this.invoiceDate = invoiceDate;
        this.customerName = customerName;
        InvoiceLines = invoiceLines;
    }

    public int getInvoiceNum() {
        return invoiceNum;
    }

    public void setInvoiceNum(int invoiceNum) {
        this.invoiceNum = invoiceNum;
    }

    public String getInvoiceDate() {

        return invoiceDate=invoiceDate.replace("-","/");
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void print(){
        System.out.println("Invoice"+getInvoiceNum()+"Num");
        System.out.println("{");
        System.out.println("Invoice"+getInvoiceNum()+"Date ("+getInvoiceDate().toString()+")," + getCustomerName());
                  for(InvoiceLine line : InvoiceLines) {
                      System.out.println(line);
                  }
        System.out.println("}");

    }
}
