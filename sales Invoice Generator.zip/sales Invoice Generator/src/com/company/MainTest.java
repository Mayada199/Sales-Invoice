package com.company;

import controller.ReadFromInvoiceHeader;

import java.io.FileNotFoundException;
import java.io.IOException;

public class MainTest {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        String csvFile = System.getProperty("user.dir") + "/src/InvoiceHeader.csv";
        ReadFromInvoiceHeader.read(csvFile);

    }
}
