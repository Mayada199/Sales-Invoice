package com.company;

import controller.ReadFromInvoiceHeader;

public class MainTest {
    public static void main(String[] args) {
        String csvFile = System.getProperty("user.dir")+"\\resources\\InvoiceHeader.csv";
        ReadFromInvoiceHeader.read(csvFile);

    }
}
