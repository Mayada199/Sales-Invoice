package com.company;

import controller.ReadFromInvoiceHeader;

import java.io.FileNotFoundException;
import java.io.IOException;

public class MainTest {
    public static void main(String[] args){
        String csvFile = System.getProperty("user.dir") + "\\resources\\InvoiceHeader.csv";
        ReadFromInvoiceHeader.read(csvFile);

    }
}
